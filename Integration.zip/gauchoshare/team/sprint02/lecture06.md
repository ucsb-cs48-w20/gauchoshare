# Stand-up Meeting 1/27/20

### Chris
* Finished Profile UI page prototype
* Waiting for backend people to finish authentication to connect with backend

### Yuehan
* Still working on items UI list
* Still not familiar enough with Android Studio

### Boru
* Almost finished with search function UI

### Huiyu
* Finished setting up Firebase database/account
* Will work with Peizhen on finalizing authentication

### Peizhen
* Still trying to get authentication to work
* Facebook and Google authentication still buggy

### Kyle Stubbs
* Finished messaging UI and homepage
* Will try to work on backend of search function

