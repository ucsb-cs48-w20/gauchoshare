# Stand-up Meeting 1/23/20

### Chris
* Started working on Profile UI page

### Yuehan
* Started working on items list UI

### Boru
* Started working on search function UI

### Huiyu
* Will work on setting up Firebase account and database.

### Peizhen
* Will begin working on authentication

### Kyle Stubbs
* Will begin working on messaging UI and homepage