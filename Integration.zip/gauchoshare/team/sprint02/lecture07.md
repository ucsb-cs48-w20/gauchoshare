# Stand-up Meeting 1/29/20

### Chris
* Still waiting for backend people to finish authentication to connect with backend
* Needs to look for more issues to do

### Yuehan
* Finish items UI list prototype
* Only the frontend is finished, so will need to familiarize himself with Firebase in order to work on the backend

### Boru
* Finished with search function UI
* Needs to look for more issues to do

### Huiyu
* Still working with Peizhen on setting up authentication using Firebase

### Peizhen
* Still working on user authentication with Huiyu

### Kyle Stubbs
* Still working on search function backend

## Other Comments
* Everyone is largely unfamiliar with Firebase and the tasks everyone is assigned all inherently involve being able to interact with Firebase, so everyone will need to familiarize themself with Firebase somehow.