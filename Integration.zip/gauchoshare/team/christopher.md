My name is Christopher Yang, and I am currently a second your undergraduate student at UCSB pursuing a Bachelor's degree in computer science.

For this project, we will start off with creating the project on the Android platform, but my idea will be to make it cross-platform and make the project available on a web platform, if time allows.
