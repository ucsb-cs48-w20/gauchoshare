My name is Kyle Stubbs and I am currently a second year computer science student. The languages that I have previously used in the past are C++ and Java.

For this project, I think that we should either make a web or mobile application to help students buy and sell items. We can also later discuss if we are able to make this work across platforms.
