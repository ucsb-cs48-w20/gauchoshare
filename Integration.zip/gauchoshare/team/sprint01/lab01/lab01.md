# Stand-up Meeting 1/16/20
* backend team is not sure how to divide up the tasks
* backend team needs to implement user authentication but this task is difficult to do without having the frontend done yet
* backend team is also largely unfamiliar with using Firebase, so one of our goals for this upcoming week is to familiarize ourselves with using Firebase, as well as Android Studio
* frontend team has a good idea as to what the UI will look like for the login page, which will make it easier for the backend team when dealing with the backend for user authentication
* frontend team is still debating whether to use vanilla javascript or React Native
