Peizhen Tong

Junior CS student with strong algorithm background.

In my opinion, this project is used as a second hand selling platform for the UCSB students.
