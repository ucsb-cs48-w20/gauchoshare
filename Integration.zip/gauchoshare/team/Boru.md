Hello everyone, my name is Boru Ai, and I am now in my thrid year of UCSB, and my major is Computer Science. 
Hope we can have a great time together and make something incredible!
