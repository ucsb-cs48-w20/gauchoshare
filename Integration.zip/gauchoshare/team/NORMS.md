Team Norms:
Arrive to lectures and sections on time.
Stay in chat with each other through slack.
Decisions are made by collaborative discussions and negotiations.
Follow DDLs.

