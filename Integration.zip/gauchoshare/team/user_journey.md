* User can post a listing of an item (textbook, furniture, notes, etc.) that he/she wants to sell to other GauchoShare users
* User can view listings posted by other Users
* User can filter listings based on desired categories
* User can communicate directly with buyer/seller through the app
